package com.example.pubgailevel

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: LinearLayout? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun showOverlay() {
        if (overlayView != null) return

        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xEE172117.toInt())
        }

        val title = TextView(this).apply {
            text = "PUBG AI • مساعد"
            textSize = 14f
            setTextColor(0xFFB5E853.toInt())
        }
        val info = TextView(this).apply {
            text = "متابعة التقدم فقط\\nلا يوجد تحكم تلقائي باللعبة"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(6), 0, dp(8))
        }
        val close = Button(this).apply {
            text = "إغلاق النافذة"
            setOnClickListener { stopSelf() }
        }

        panel.addView(title)
        panel.addView(info)
        panel.addView(close)

        val params = WindowManager.LayoutParams(
            dp(210),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(12)
            y = dp(120)
        }

        windowManager?.addView(panel, params)
        overlayView = panel
    }

    override fun onDestroy() {
        overlayView?.let { view ->
            try { windowManager?.removeView(view) } catch (_: Exception) {}
        }
        overlayView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
