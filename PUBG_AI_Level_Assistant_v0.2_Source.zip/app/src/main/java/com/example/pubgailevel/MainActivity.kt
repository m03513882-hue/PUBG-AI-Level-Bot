package com.example.pubgailevel

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF101510)
private val Panel = Color(0xFF1B241B)
private val Green = Color(0xFF9BCB38)
private val Muted = Color(0xFFAAB5A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("progress", MODE_PRIVATE)
        setContent {
            var level by remember { mutableStateOf(prefs.getInt("level", 1).toString()) }
            var xp by remember { mutableStateOf(prefs.getInt("xp", 0).toString()) }
            var targetXp by remember { mutableStateOf(prefs.getInt("targetXp", 1000).toString()) }
            var matches by remember { mutableIntStateOf(prefs.getInt("matches", 0)) }
            var overlayOn by remember { mutableStateOf(false) }
            var note by remember { mutableStateOf("جاهز — احفظ بياناتك ثم فعّل النافذة العائمة") }

            val lv = level.toIntOrNull()?.coerceIn(1, 100) ?: 1
            val currentXp = xp.toIntOrNull()?.coerceAtLeast(0) ?: 0
            val goalXp = targetXp.toIntOrNull()?.coerceAtLeast(1) ?: 1
            val progress = (currentXp.toFloat() / goalXp).coerceIn(0f, 1f)

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Green, background = Bg, surface = Panel,
                onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
            )) {
                Column(
                    Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("PUBG", color = Green, fontSize = 15.sp, fontWeight = FontWeight.Black)
                    Text("AI LEVEL ASSISTANT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    Text("GLOBAL • POCO F3", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(22.dp))

                    CardBox {
                        Text("مستوى الحساب", color = Muted, fontSize = 14.sp)
                        Text("$lv", color = Green, fontSize = 54.sp, fontWeight = FontWeight.Black)
                        Text("الهدف: Level 45", color = Color.White, fontSize = 15.sp)
                        LinearProgressIndicator(
                            progress = { (lv / 45f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(9.dp),
                            color = Green, trackColor = Color(0xFF354235)
                        )
                        Text("${((lv / 45f).coerceIn(0f, 1f) * 100).toInt()}% من الهدف", color = Muted)
                    }
                    Spacer(Modifier.height(14.dp))

                    CardBox {
                        Text("تسجيل الخبرة XP", color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        NumberField("المستوى الحالي", level) { level = it }
                        NumberField("XP الحالي في المستوى", xp) { xp = it }
                        NumberField("XP المطلوب للمستوى التالي", targetXp) { targetXp = it }
                        Text("التقدم داخل المستوى", color = Muted, fontSize = 13.sp)
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth().height(8.dp),
                            color = Green, trackColor = Color(0xFF354235)
                        )
                        Text("$currentXp / $goalXp XP", color = Color.White)
                        Button(
                            onClick = {
                                prefs.edit().putInt("level", lv)
                                    .putInt("xp", currentXp).putInt("targetXp", goalXp)
                                    .putInt("matches", matches).apply()
                                note = "تم حفظ تقدمك على الجهاز"
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green)
                        ) { Text("حفظ التقدم", color = Color.Black, fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(14.dp))

                    CardBox {
                        Text("متابعة المباريات", color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("عدد المباريات المسجلة: $matches", color = Color.White)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { matches++; note = "تم تسجيل مباراة" }) { Text("+ مباراة") }
                            OutlinedButton(onClick = { if (matches > 0) matches--; note = "تم التراجع" }) { Text("تراجع") }
                        }
                    }
                    Spacer(Modifier.height(14.dp))

                    CardBox {
                        Text("النافذة العائمة", color = Green, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            "تظهر فوق التطبيقات لعرض تذكير سريع وتقدمك. لا تتحكم في PUBG ولا تنفذ ضغطات داخل اللعبة.",
                            color = Muted, fontSize = 13.sp
                        )
                        Button(
                            onClick = {
                                if (Settings.canDrawOverlays(this@MainActivity)) {
                                    startService(Intent(this@MainActivity, OverlayService::class.java))
                                    overlayOn = true
                                    note = "تم طلب تشغيل النافذة العائمة"
                                } else {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:$packageName")
                                    )
                                    startActivity(intent)
                                    note = "اسمح بالظهور فوق التطبيقات ثم ارجع واضغط تشغيل"
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Green)
                        ) { Text("تشغيل النافذة العائمة", color = Color.Black, fontWeight = FontWeight.Bold) }
                        OutlinedButton(
                            onClick = {
                                stopService(Intent(this@MainActivity, OverlayService::class.java))
                                overlayOn = false
                                note = "تم طلب إيقاف النافذة"
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("إيقاف النافذة") }
                        Text(note, color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("نسخة تجريبية 0.2 • POCO F3", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { onValue(it.filter(Char::isDigit)) },
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Green, focusedLabelColor = Green,
            cursorColor = Green, unfocusedBorderColor = Color(0xFF526052)
        )
    )
}
